export DEBIAN_FRONTEND="${DEBIAN_FRONTEND:-noninteractive}" GIT_TERMINAL_PROMPT="${GIT_TERMINAL_PROMPT:-0}" PAGER="${PAGER:-cat}" GIT_PAGER="${GIT_PAGER:-cat}"
__hs_stdin=/tmp/hoplite/shell/rewardfoxseat/stdin
__hs_dir=.hoplite/runtime/shell/rewardfoxseat
trap 'rm -f -- "$__hs_stdin" "$__hs_dir/stdin" 2>/dev/null || true; rmdir -- "$(dirname -- "$__hs_stdin")" 2>/dev/null || true' EXIT
trap 'rm -f -- "$__hs_stdin" "$__hs_dir/stdin" 2>/dev/null || true; rmdir -- "$(dirname -- "$__hs_stdin")" 2>/dev/null || true; trap - HUP; kill -HUP $$' HUP
trap 'rm -f -- "$__hs_stdin" "$__hs_dir/stdin" 2>/dev/null || true; rmdir -- "$(dirname -- "$__hs_stdin")" 2>/dev/null || true; trap - INT; kill -INT $$' INT
trap 'rm -f -- "$__hs_stdin" "$__hs_dir/stdin" 2>/dev/null || true; rmdir -- "$(dirname -- "$__hs_stdin")" 2>/dev/null || true; trap - TERM; kill -TERM $$' TERM
if [ -p "$__hs_stdin" ]; then exec 0<>"$__hs_stdin"; else exec 0</dev/null; fi
exec 1>>.hoplite/runtime/shell/rewardfoxseat/out 2>>.hoplite/runtime/shell/rewardfoxseat/err
export HOPLITE_OOM_MARKER_FD=2
{ printf '%s\n' -900 > /proc/self/oom_score_adj; } 2>/dev/null || true
__hs_pre="$(awk '$1 == "oom_kill" { print $2; found = 1 } END { exit !found }' /sys/fs/cgroup/memory.events 2>/dev/null || awk '$1 == "oom_kill" { print $2; found = 1 } END { exit !found }' /proc/vmstat 2>/dev/null || echo 0)"
__hs_t0_ns=$(date +%s%N 2>/dev/null); case "$__hs_t0_ns" in ''|*[!0-9]*) __hs_t0_ns= ;; esac
( { printf '%s\n' 300 > /proc/self/oom_score_adj; } 2>/dev/null || true; umask 022; exec env HOPLITE_SHELL_SESSION_ID=rewardfoxseat timeout --kill-after=10 60 env -u BASH_ENV -u ENV bash --noprofile --norc -c 'cd /tmp/hoplite/workspace/Bcore/src/main/cpp && cat BoxCore.cpp | head -150; echo '\''=== RuntimeHook.cpp ==='\''; cat Hook/RuntimeHook.cpp; echo '\''=== VMClassLoaderHook.cpp ==='\''; sed -n '\''1,80p'\'' Hook/VMClassLoaderHook.cpp' ) 0<&0 9>&- &
__hs_cmd="$!"
printf '%s' "$__hs_cmd" > .hoplite/runtime/shell/rewardfoxseat/cmd.pid
__hs_stat="$(cat "/proc/$__hs_cmd/stat" 2>/dev/null)"; __hs_rest="${__hs_stat##*) }"; set -- $__hs_rest
printf '%s' "${20:-}" > .hoplite/runtime/shell/rewardfoxseat/cmd.start
__hs_self=$$
( __hs_prev=; while [ ! -f .hoplite/runtime/shell/rewardfoxseat/exit ] && kill -0 "$__hs_self" 2>/dev/null; do sleep 1 2>/dev/null || sleep 1; __hs_o=$( { wc -c < .hoplite/runtime/shell/rewardfoxseat/out; } 2>/dev/null ); __hs_e=$( { wc -c < .hoplite/runtime/shell/rewardfoxseat/err; } 2>/dev/null ); __hs_cur="$(( ${__hs_o:-0} + 0 )) $(( ${__hs_e:-0} + 0 ))"; if [ "$__hs_cur" != "$__hs_prev" ]; then printf '%s %s\n' "$(date +%s)" "$__hs_cur" >> .hoplite/runtime/shell/rewardfoxseat/idx; __hs_prev="$__hs_cur"; fi; done ) </dev/null >/dev/null 2>&1 &
wait "$__hs_cmd"
__hs_rc=$?
__hs_t1_ns=$(date +%s%N 2>/dev/null); case "$__hs_t1_ns" in ''|*[!0-9]*) __hs_t1_ns= ;; esac; if [ -n "$__hs_t0_ns" ] && [ -n "$__hs_t1_ns" ]; then __hs_ran_ns=$(( __hs_t1_ns - __hs_t0_ns )); else __hs_ran_ns=; fi
__hs_starttime() { __hs_line="$(cat "/proc/$1/stat" 2>/dev/null)" || return 1; __hs_rest="${__hs_line##*) }"; set -- $__hs_rest; printf '%s' "${20:-}"; }
__hs_leftovers() { for __hs_env in /proc/[0-9]*/environ; do __hs_p="${__hs_env#/proc/}"; __hs_p="${__hs_p%/environ}"; [ "$__hs_p" = "$$" ] && continue; if { tr '\0' '\n' < "$__hs_env"; } 2>/dev/null | grep -qxF -- 'HOPLITE_SHELL_SESSION_ID=rewardfoxseat'; then __hs_born="$(__hs_starttime "$__hs_p")" && [ -n "$__hs_born" ] && printf '%s:%s ' "$__hs_p" "$__hs_born"; fi; done; }
__hs_signal() { __hs_sig="$1"; shift; for __hs_t in "$@"; do __hs_p="${__hs_t%%:*}"; if [ "$(__hs_starttime "$__hs_p")" = "${__hs_t#*:}" ]; then kill "-$__hs_sig" "$__hs_p" 2>/dev/null; fi; done; return 0; }
if { { [ "$__hs_rc" = 124 ] && [ -n "$__hs_ran_ns" ] && [ "$__hs_ran_ns" -ge 60000000000 ]; } || { [ "$__hs_rc" = 137 ] && [ -n "$__hs_ran_ns" ] && [ "$__hs_ran_ns" -ge 70000000000 ]; }; } && [ -r /proc/self/environ ]; then
  __hs_left="$(__hs_leftovers)"; set -- $__hs_left; __hs_found=$#
  if [ "$__hs_found" -gt 0 ]; then
    __hs_signal TERM "$@"
    __hs_i=0; while [ "$__hs_i" -lt 25 ] && [ -n "$(__hs_leftovers)" ]; do sleep 0.2 2>/dev/null || sleep 1; __hs_i=$(( __hs_i + 1 )); done
    __hs_left="$(__hs_leftovers)"; set -- $__hs_left
    if [ "$#" -gt 0 ]; then __hs_signal KILL "$@"; sleep 0.5 2>/dev/null || sleep 1; __hs_left="$(__hs_leftovers)"; set -- $__hs_left; fi
  fi
  printf '%s,%s' "$__hs_found" "$#" > .hoplite/runtime/shell/rewardfoxseat/sweep
fi
rm -f -- "$__hs_stdin" "$__hs_dir/stdin" 2>/dev/null || true
rmdir -- "$(dirname -- "$__hs_stdin")" 2>/dev/null || true
__hs_post="$(awk '$1 == "oom_kill" { print $2; found = 1 } END { exit !found }' /sys/fs/cgroup/memory.events 2>/dev/null || awk '$1 == "oom_kill" { print $2; found = 1 } END { exit !found }' /proc/vmstat 2>/dev/null || echo 0)"
printf '%s %s' "$__hs_pre" "$__hs_post" > .hoplite/runtime/shell/rewardfoxseat/oom
if [ "$__hs_post" != "$__hs_pre" ]; then printf '\n__HOPLITE_OOM_KILLS__ v2f1dp84ll85hwfo %s %s\n' "$__hs_pre" "$__hs_post" >&2; fi
printf '%s' "$__hs_rc" > .hoplite/runtime/shell/rewardfoxseat/exit.tmp
mv .hoplite/runtime/shell/rewardfoxseat/exit.tmp .hoplite/runtime/shell/rewardfoxseat/exit